import React from 'react';  

function Header({ newTodo, setNewTodo, addTodo }) {  
  return (  
    <div className="header">  
      <h1>To-Do List</h1>  
      <div className="input-group">  
        <input  
          type="text"  
          placeholder="Add a new task"  
          value={newTodo}  
          onChange={(e) => setNewTodo(e.target.value)}  
          onKeyDown={(e) => { if (e.key === 'Enter') addTodo(); }}  
          className="form-control"  
        />  
        <button onClick={addTodo} className="btn btn-primary">  
          <i className="bi bi-plus-lg"></i> Add  
        </button>  
      </div>  
    </div>  
  );  
}  

export default Header;  