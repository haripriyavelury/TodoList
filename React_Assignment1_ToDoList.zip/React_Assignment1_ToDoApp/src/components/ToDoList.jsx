import React from 'react';  
import ToDoItem from './ToDoItem';  

function ToDoList({ todos, toggleComplete, deleteTodo, editTodo, editingTodoId, editText, setEditText, updateTodo }) {  
  return (  
    <ul className="todo-list">  
      {todos.map(todo => (  
        <ToDoItem  
          key={todo.id}  
          todo={todo}  
          toggleComplete={toggleComplete}  
          deleteTodo={deleteTodo}  
          editTodo={editTodo}  
          editingTodoId={editingTodoId}  
          editText={editText}  
          setEditText={setEditText}  
          updateTodo={updateTodo}  
        />  
      ))}  
    </ul>  
  );  
}  

export default ToDoList;  