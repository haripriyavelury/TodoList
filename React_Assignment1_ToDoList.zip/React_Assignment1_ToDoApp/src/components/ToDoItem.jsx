import React from 'react';  

function ToDoItem({ todo, toggleComplete, deleteTodo, editTodo, editingTodoId, editText, setEditText, updateTodo }) {  
  const isEditing = editingTodoId === todo.id;  

  return (  
    <li className={`todo-item ${todo.completed ? 'completed' : ''}`}>  
      {isEditing ? (  
        <div className="edit-container">  
          <input  
            type="text"  
            value={editText}  
            onChange={(e) => setEditText(e.target.value)}  
            onKeyDown={(e) => { if (e.key === 'Enter') updateTodo(); }}  
            className="form-control"  
          />  
          <button onClick={updateTodo} className="btn btn-success">  
            <i className="bi bi-check-lg"></i>
             Update  
          </button>  
        </div>  
      ) : (  
        <div className="display-container">  
          <input  
            type="checkbox"  
            checked={todo.completed}  
            onChange={() => toggleComplete(todo.id)}  
          />  
          {todo.completed} 
          <span className="todo-text">{todo.text}</span>  
          <div className="todo-actions">  
            <button onClick={() => editTodo(todo.id)} className="btn btn-warning">  
              <i className="bi bi-pencil-square"></i> Edit  
            </button>  
            <button onClick={() => deleteTodo(todo.id)} className="btn btn-danger">  
              <i className="bi bi-trash"></i> Delete  
            </button>  
          </div>  
        </div>  
      )}  
    </li>  
  );  
}  

export default ToDoItem;  