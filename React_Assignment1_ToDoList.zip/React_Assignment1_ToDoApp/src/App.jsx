import React, { useState, useEffect } from 'react';  
import Header from './components/Header';  
import ToDoList from './components/ToDoList';  
import './App.css';  
import 'bootstrap-icons/font/bootstrap-icons.css';  

function App() {  
  const [todos, setTodos] = useState(() => {  
    const storedTodos = localStorage.getItem('todos');  
    return storedTodos ? JSON.parse(storedTodos) : [];  
  });  
  const [newTodo, setNewTodo] = useState('');  
  const [editingTodoId, setEditingTodoId] = useState(null);  
  const [editText, setEditText] = useState('');  

  useEffect(() => {  
    localStorage.setItem('todos', JSON.stringify(todos));  
  }, [todos]);  

  const addTodo = () => {  
    if (newTodo.trim() !== '') {  
      setTodos([...todos, { id: Date.now(), text: newTodo.trim(), completed: false }]);  
      setNewTodo('');  
    }  
  };  

  const toggleComplete = (id) => {  
    setTodos(todos.map(todo =>  
      todo.id === id ? { ...todo, completed: !todo.completed } : todo  
    ));  
  };  

  const deleteTodo = (id) => {  
    setTodos(todos.filter(todo => todo.id !== id));  
  };  

  const editTodo = (id) => {  
    setEditingTodoId(id);  
    const todoToEdit = todos.find(todo => todo.id === id);  
    setEditText(todoToEdit.text);  
  };  

  const updateTodo = () => {  
    if (editText.trim() !== '') {  
      setTodos(todos.map(todo =>  
        todo.id === editingTodoId ? { ...todo, text: editText.trim() } : todo  
      ));  
      setEditingTodoId(null);  
      setEditText('');  
    }  
  };  

  return (  
    <div className="app container">  
      <Header newTodo={newTodo} setNewTodo={setNewTodo} addTodo={addTodo} />  
      <ToDoList  
        todos={todos}  
        toggleComplete={toggleComplete}  
        deleteTodo={deleteTodo}  
        editTodo={editTodo}  
        editingTodoId={editingTodoId}  
        editText={editText}  
        setEditText={setEditText}  
        updateTodo={updateTodo}  
      />  
    </div>  
  );  
}  

export default App;  